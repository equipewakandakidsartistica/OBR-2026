# Projeto camera > 2026-04-09 9:18am
https://universe.roboflow.com/equipewakandakidsartsticas-workspace/projeto-camera

Provided by a Roboflow user
License: CC BY 4.0

